var express 	= require('express');
var router 		= express.Router();
var userModel   = require.main.require('./models/user-model');
var md5 = require('md5');

router.get('*', function(req, res, next){
	if(req.cookies['token'] == null){
		res.redirect('/login');
	}else{
		next();
	}
});




router.get('/', function(req, res){
	
	if(req.cookies['token'] != null){
		console.log(req.cookies['token']);
		userModel.getByUname(req.cookies['uname'], function(result){
			res.render('Employee/index', {user: result});
		});

	}else{
		res.redirect('/logout');
	}
});



router.get('/myprofile', function(req, res){

	if(req.cookies['token'] != null){
		userModel.jobDetails("",function(results){
			res.render('Employee/myprofile', {userlist: results});
		
	});

	}else{
		res.redirect('/logout');
	}

	
});



router.get('/UpdateProfile', function(req, res){

	if(req.cookies['token'] != null){
		userModel.jobDetails(null,function(results){
		if(results.length > 0){
			res.render('Employee/UpdateProfile', {userlist: results});
		}else{
			res.send('no users found');
		}
	});

	}else{
		res.redirect('/logout');
	}

	
});



router.get('/Updatee/:id', function(req, res){
	var ID = req.params.id;
	userModel.getById(ID,function(results){
		if(results!=null){
			res.render('admin/Update', {details: results});
		}else{
			res.send('Not working');
		}
	});
});


router.post('/Updatee/:id', function(req, res){
	var info ={
		uid : req.params.id,
		name : req.body.name,
		username : req.body.username,
		password : req.body.password,
		contact : req.body.contact,
		type : req.body.type
	};
	userModel.update(info,function(status){
		if(status){
			res.redirect('../UpdateProfile');
		}else{
			res.send('Not working');
		}
	});
});



module.exports = router;

