var express 	= require('express');
var router 		= express.Router();
var userModel   = require.main.require('./models/user-model');
const { check, validationResult } = require('express-validator');
var md5 = require('md5');

router.get('*', function(req, res, next){
	if(req.cookies['token'] == null){
		res.redirect('/login');
	}else{
		next();
	}
});




router.get('/', function(req, res){
	
	if(req.cookies['token'] != null){
		console.log(req.cookies['token']);
		userModel.getByUname(req.cookies['uname'], function(result){
			res.render('admin/index', {user: result});
		});

	}else{
		res.redirect('/logout');
	}
});

router.get('/AllEmployeeList', function(req, res){

	if(req.cookies['token'] != null){
		userModel.userGetAll(null,function(results){
		if(results.length > 0){
			res.render('admin/AllEmployeeList', {userlist: results});
		}else{
			res.send('no users found');
		}
	});

	}else{
		res.redirect('/logout');
	}

	
});


router.get('/AddEmployee', function(req, res){

	res.render('admin/AddEmployee');
});

router.post('/AddEmployee', function(req, res){

	var info = {
		name : req.body.name,
		username : req.body.username,
		password : req.body.password,
		contact : req.body.contact,
		type : "emp",
		comName: req.body.comName
	}

	userModel.insert(info,function(status){
		if (status) {
			res.redirect('AllEmployeeList');
		}
		else{
			res.redirect('AddEmployee');
		}
	});


});



router.get('/Update/:id', function(req, res){
	var ID = req.params.id;
	userModel.getById(ID,function(results){
		if(results!=null){
			res.render('admin/Update', {details: results});
		}else{
			res.send('Not working');
		}
	});
});


router.post('/Update/:id', function(req, res){
	var info ={
		uid : req.params.id,
		name : req.body.name,
		username : req.body.username,
		password : req.body.password,
		contact : req.body.contact,
		type : req.body.type
	};
	userModel.update(info,function(status){
		if(status){
			res.redirect('../AllEmployeeList');
		}else{
			res.send('Not working');
		}
	});
});


router.get('/delete/:id', function(req, res){
	var ID = req.params.id;
	userModel.getById(ID,function(results){
		if(results!=null){
			res.render('admin/delete', {details: results});
		}else{
			res.send('Not working');
		}
	});
});


router.post('/delete/:id', function(req, res){
	var ID = req.params.id;
	userModel.delete(ID,function(status){
		if(status){
			res.redirect('../AllEmployeeList');
		}else{
			res.send('Not working');
		}
	});
});


module.exports = router;

